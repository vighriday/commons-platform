import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { GoogleGenAI, Modality } from '@google/genai';
import dotenv from 'dotenv';

// Load environment variables in development
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Lazy initialization of Gemini client to prevent startup crashes
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is required. Please configure it in Settings > Secrets.');
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  // Set generous limit for image uploads
  app.use(express.json({ limit: '10mb' }));

  // --- API Endpoints ---

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', hasKey: !!process.env.GEMINI_API_KEY });
  });

  // 1. Text Generation Endpoint
  app.post('/api/gemini/generate', async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { prompt, systemInstruction, image, temperature } = req.body;

      if (!prompt) {
        res.status(400).json({ error: 'Prompt is required' });
        return;
      }

      let contents: any = prompt;

      // If an image is provided (base64 data URL)
      if (image && typeof image === 'string') {
        const matches = image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
        if (matches && matches.length === 3) {
          const mimeType = matches[1];
          const base64Data = matches[2];
          contents = {
            parts: [
              {
                inlineData: {
                  data: base64Data,
                  mimeType: mimeType,
                },
              },
              { text: prompt },
            ],
          };
        }
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents,
        config: {
          systemInstruction: systemInstruction || 'You are a helpful, highly capable, and creative AI assistant.',
          temperature: temperature !== undefined ? Number(temperature) : 0.7,
        },
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error('Error in text generation:', error);
      res.status(500).json({ error: error.message || 'Failed to generate text' });
    }
  });

  // 2. Text-to-Speech Endpoint
  app.post('/api/gemini/tts', async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { text, voiceName } = req.body;

      if (!text) {
        res.status(400).json({ error: 'Text is required for TTS' });
        return;
      }

      const validVoices = ['Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'];
      const selectedVoice = validVoices.includes(voiceName) ? voiceName : 'Zephyr';

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-flash-tts-preview',
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: selectedVoice },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        throw new Error('No audio data received from Gemini API');
      }

      res.json({ audio: base64Audio });
    } catch (error: any) {
      console.error('Error in speech generation:', error);
      res.status(500).json({ error: error.message || 'Failed to generate speech' });
    }
  });

  // 3. Image Generation / Editing Endpoint
  app.post('/api/gemini/image', async (req, res) => {
    try {
      const ai = getGeminiClient();
      const { prompt, aspectRatio, inputImage } = req.body;

      if (!prompt) {
        res.status(400).json({ error: 'Prompt is required' });
        return;
      }

      let response;

      if (inputImage && typeof inputImage === 'string') {
        // Image Editing Mode (Inpainting / Image-to-Image)
        const matches = inputImage.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
        if (!matches || matches.length !== 3) {
          res.status(400).json({ error: 'Invalid input image format' });
          return;
        }
        const mimeType = matches[1];
        const base64Data = matches[2];

        response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              {
                inlineData: {
                  data: base64Data,
                  mimeType: mimeType,
                },
              },
              { text: prompt },
            ],
          },
        });
      } else {
        // Text-to-Image Generation Mode
        const validAspectRatios = ['1:1', '3:4', '4:3', '9:16', '16:9'];
        const selectedAspectRatio = validAspectRatios.includes(aspectRatio) ? aspectRatio : '1:1';

        response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [
              { text: prompt },
            ],
          },
          config: {
            imageConfig: {
              aspectRatio: selectedAspectRatio,
            },
          },
        });
      }

      // Find the generated image part in the response
      let base64Image = null;
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData && part.inlineData.data) {
            base64Image = part.inlineData.data;
            break;
          }
        }
      }

      if (!base64Image) {
        throw new Error('No image was returned by the model. Check your prompt safety settings or try again.');
      }

      res.json({ image: base64Image });
    } catch (error: any) {
      console.error('Error in image generation:', error);
      res.status(500).json({ error: error.message || 'Failed to generate image' });
    }
  });

  // --- Serve Frontend Application ---

  if (process.env.NODE_ENV !== 'production') {
    // In development: mount Vite dev server as middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);
    
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // In production: serve statically built assets
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const port = 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`Server started at http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
