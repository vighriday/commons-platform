/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useTransition } from 'react';
import { 
  Sparkles, 
  MessageSquare, 
  Volume2, 
  Image as ImageIcon, 
  Upload, 
  Trash2, 
  Play, 
  Pause, 
  Download, 
  RefreshCw, 
  Copy, 
  Check, 
  Sliders, 
  ChevronRight, 
  HelpCircle,
  Maximize2,
  Minimize2,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Interfaces & Types
type AppMode = 'text' | 'speech' | 'image';

interface StatusState {
  connected: boolean;
  checked: boolean;
  message: string;
}

export default function App() {
  // Navigation & General App State
  const [mode, setMode] = useState<AppMode>('text');
  const [status, setStatus] = useState<StatusState>({
    connected: false,
    checked: false,
    message: 'Checking connection...'
  });

  // Inputs
  const [prompt, setPrompt] = useState('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [systemInstruction, setSystemInstruction] = useState('You are a helpful, highly capable, and creative AI assistant.');
  const [temperature, setTemperature] = useState(0.7);
  const [voiceName, setVoiceName] = useState('Zephyr');
  const [aspectRatio, setAspectRatio] = useState('1:1');

  // Outputs
  const [textOutput, setTextOutput] = useState('');
  const [imageOutput, setImageOutput] = useState<string | null>(null);
  
  // Custom Audio Controller State
  const [audioBase64, setAudioBase64] = useState<string | null>(null);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [audioSource, setAudioSource] = useState<AudioBufferSourceNode | null>(null);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [volume, setVolume] = useState(1.0);
  const [audioDuration, setAudioDuration] = useState(0);
  const [audioProgress, setAudioProgress] = useState(0);

  // UI Utilities
  const [isPending, startTransition] = useTransition();
  const [copiedText, setCopiedText] = useState(false);
  const [copiedCodeIndex, setCopiedCodeIndex] = useState<number | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [expandedOutput, setExpandedOutput] = useState(false);

  // References
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioProgressIntervalRef = useRef<number | null>(null);
  const audioStartTimeRef = useRef<number>(0);
  const audioPausedAtRef = useRef<number>(0);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Ping API on mount to check connection
  useEffect(() => {
    checkConnection();
  }, []);

  const checkConnection = async () => {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        const data = await res.json();
        if (data.hasKey) {
          setStatus({
            connected: true,
            checked: true,
            message: 'Gemini API is ready to create.'
          });
        } else {
          setStatus({
            connected: false,
            checked: true,
            message: 'GEMINI_API_KEY is missing. Add it in Settings > Secrets.'
          });
        }
      } else {
        setStatus({
          connected: false,
          checked: true,
          message: 'Server unreachable. Attempting connection...'
        });
      }
    } catch (e) {
      setStatus({
        connected: false,
        checked: true,
        message: 'Could not connect to backend server.'
      });
    }
  };

  // Drag and Drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processImageFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processImageFile(files[0]);
    }
  };

  const processImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload a valid image file.');
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setImagePreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const clearImage = () => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Speech/Audio PCM conversion and playback
  useEffect(() => {
    if (audioBase64) {
      decodePcmAudio(audioBase64);
    }
    return () => {
      stopAudioPlayback();
    };
  }, [audioBase64]);

  const decodePcmAudio = async (base64Str: string) => {
    try {
      stopAudioPlayback();

      // Convert base64 to Uint8Array
      const binaryString = window.atob(base64Str);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert to Int16Array (PCM 16-bit little-endian)
      const buffer = bytes.buffer;
      const int16Array = new Int16Array(buffer);

      // Create AudioContext with 24000Hz sample rate (Gemini TTS Output)
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      setAudioContext(ctx);

      const bufferLen = int16Array.length;
      const audioBuf = ctx.createBuffer(1, bufferLen, 24000);
      const channelData = audioBuf.getChannelData(0);

      // Convert Int16 PCM to Float32 [-1.0, 1.0]
      for (let i = 0; i < bufferLen; i++) {
        channelData[i] = int16Array[i] / 32768.0;
      }

      setAudioBuffer(audioBuf);
      setAudioDuration(audioBuf.duration);
      setAudioProgress(0);
      audioPausedAtRef.current = 0;
    } catch (e) {
      console.error('Failed to decode PCM audio:', e);
    }
  };

  const toggleAudioPlayback = () => {
    if (isPlaying) {
      pauseAudioPlayback();
    } else {
      playAudioPlayback();
    }
  };

  const playAudioPlayback = () => {
    if (!audioContext || !audioBuffer) return;

    // Resume context if suspended
    if (audioContext.state === 'suspended') {
      audioContext.resume();
    }

    // Create a new source node
    const source = audioContext.createBufferSource();
    source.buffer = audioBuffer;
    
    // Set volume control (GainNode)
    const gainNode = audioContext.createGain();
    gainNode.gain.value = volume;

    // Connect source to gain and gain to destination
    source.connect(gainNode);
    gainNode.connect(audioContext.destination);

    // Apply playback rate
    source.playbackRate.value = playbackSpeed;

    // Offset calculation for resume
    const offset = audioPausedAtRef.current;
    source.start(0, offset);
    audioStartTimeRef.current = audioContext.currentTime - offset / playbackSpeed;

    setAudioSource(source);
    setIsPlaying(true);

    // Track Progress
    if (audioProgressIntervalRef.current) {
      window.clearInterval(audioProgressIntervalRef.current);
    }

    audioProgressIntervalRef.current = window.setInterval(() => {
      if (audioContext) {
        const elapsed = (audioContext.currentTime - audioStartTimeRef.current) * playbackSpeed;
        if (elapsed >= audioBuffer.duration) {
          stopAudioPlayback();
        } else {
          setAudioProgress(elapsed);
        }
      }
    }, 50);

    // Visualizer loop start
    startVisualizer();
  };

  const pauseAudioPlayback = () => {
    if (audioSource && audioContext) {
      audioSource.stop();
      audioPausedAtRef.current = (audioContext.currentTime - audioStartTimeRef.current) * playbackSpeed;
      if (audioProgressIntervalRef.current) {
        window.clearInterval(audioProgressIntervalRef.current);
      }
      setIsPlaying(false);
      cancelAnimationFrame(animationFrameRef.current || 0);
    }
  };

  const stopAudioPlayback = () => {
    if (audioSource) {
      try {
        audioSource.stop();
      } catch (e) {}
    }
    if (audioProgressIntervalRef.current) {
      window.clearInterval(audioProgressIntervalRef.current);
    }
    setIsPlaying(false);
    setAudioProgress(0);
    audioPausedAtRef.current = 0;
    cancelAnimationFrame(animationFrameRef.current || 0);
    drawStaticWave();
  };

  // Simple WAV export to download TTS
  const downloadAudioWav = () => {
    if (!audioBuffer) return;
    const wavBlob = bufferToWav(audioBuffer);
    const url = URL.createObjectURL(wavBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gemini-tts-${voiceName}-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Convert Float32 AudioBuffer to a download-friendly 16-bit WAV format
  const bufferToWav = (buffer: AudioBuffer): Blob => {
    const numOfChan = buffer.numberOfChannels;
    const length = buffer.length * numOfChan * 2 + 44;
    const bufferArr = new ArrayBuffer(length);
    const view = new DataView(bufferArr);
    const channels = [];
    let i;
    let sample;
    let pos = 0;
    let offset = 0;

    const setUint16 = (data: number) => {
      view.setUint16(pos, data, true);
      pos += 2;
    };

    const setUint32 = (data: number) => {
      view.setUint32(pos, data, true);
      pos += 4;
    };

    // Write WAV Header
    setUint32(0x46464946);                         // "RIFF"
    setUint32(length - 8);                         // file length - 8
    setUint32(0x45564157);                         // "WAVE"
    setUint32(0x20746d66);                         // "fmt " chunk
    setUint32(16);                                 // chunk length
    setUint16(1);                                  // sample format (PCM)
    setUint16(numOfChan);                          // channel count
    setUint32(buffer.sampleRate);                  // sample rate
    setUint32(buffer.sampleRate * 2 * numOfChan);  // byte rate
    setUint16(numOfChan * 2);                      // block align
    setUint16(16);                                 // bits per sample
    setUint32(0x61746164);                         // "data" chunk
    setUint32(length - pos - 4);                   // chunk length

    for (i = 0; i < buffer.numberOfChannels; i++) {
      channels.push(buffer.getChannelData(i));
    }

    while (pos < length) {
      for (i = 0; i < numOfChan; i++) {
        sample = Math.max(-1, Math.min(1, channels[i][offset]));
        sample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
        view.setInt16(pos, sample, true);
        pos += 2;
      }
      offset++;
    }

    return new Blob([bufferArr], { type: 'audio/wav' });
  };

  // SVG-like wave drawing on standard Canvas for TTS
  useEffect(() => {
    drawStaticWave();
  }, [audioBuffer]);

  const drawStaticWave = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = 'rgba(51, 65, 85, 0.4)';
    const barWidth = 3;
    const gap = 2;
    const totalBars = Math.floor(canvas.width / (barWidth + gap));

    for (let i = 0; i < totalBars; i++) {
      const height = 10 + Math.sin(i * 0.15) * 20 + Math.cos(i * 0.05) * 10;
      const x = i * (barWidth + gap);
      const y = (canvas.height - height) / 2;
      ctx.fillRect(x, y, barWidth, height);
    }
  };

  const startVisualizer = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const barWidth = 3;
    const gap = 2;
    const totalBars = Math.floor(canvas.width / (barWidth + gap));

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const time = Date.now() * 0.01;

      for (let i = 0; i < totalBars; i++) {
        const progressRatio = audioProgress / (audioDuration || 1);
        const barRatio = i / totalBars;
        const isPast = barRatio <= progressRatio;

        // Visual waves reflecting current active playback
        const activeMod = isPlaying ? Math.sin(i * 0.2 + time) * 15 + Math.cos(i * 0.1 - time * 0.5) * 10 : 0;
        const height = Math.max(6, 12 + Math.sin(i * 0.1) * 15 + activeMod);

        const x = i * (barWidth + gap);
        const y = (canvas.height - height) / 2;

        ctx.fillStyle = isPast ? '#6366f1' : 'rgba(100, 116, 139, 0.4)'; // Indigo for played, slate for remaining
        ctx.fillRect(x, y, barWidth, height);
      }
      animationFrameRef.current = requestAnimationFrame(animate);
    };

    animate();
  };

  // API Call handlers
  const handleGenerate = () => {
    if (!prompt.trim() && mode !== 'image') {
      alert('Please enter a prompt.');
      return;
    }

    stopAudioPlayback();
    setTextOutput('');
    setImageOutput(null);
    setAudioBase64(null);
    setAudioBuffer(null);

    startTransition(async () => {
      try {
        if (mode === 'text') {
          const bodyPayload: any = {
            prompt: prompt,
            systemInstruction: systemInstruction,
            temperature: temperature
          };
          if (imagePreview) {
            bodyPayload.image = imagePreview;
          }

          const res = await fetch('/api/gemini/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyPayload)
          });

          if (!res.ok) {
            const errData = await res.json();
            throw new Error(errData.error || 'Failed to generate text content');
          }

          const data = await res.json();
          setTextOutput(data.text);
        } else if (mode === 'speech') {
          const res = await fetch('/api/gemini/tts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              text: prompt,
              voiceName: voiceName
            })
          });

          if (!res.ok) {
            const errData = await res.json();
            throw new Error(errData.error || 'Failed to synthesize speech');
          }

          const data = await res.json();
          setAudioBase64(data.audio);
        } else if (mode === 'image') {
          const bodyPayload: any = {
            prompt: prompt || 'A highly detailed visual artwork',
            aspectRatio: aspectRatio
          };
          if (imagePreview) {
            bodyPayload.inputImage = imagePreview;
          }

          const res = await fetch('/api/gemini/image', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bodyPayload)
          });

          if (!res.ok) {
            const errData = await res.json();
            throw new Error(errData.error || 'Failed to generate image');
          }

          const data = await res.json();
          setImageOutput(`data:image/png;base64,${data.image}`);
        }
      } catch (e: any) {
        console.error(e);
        alert(e.message || 'An error occurred during generation.');
      }
    });
  };

  const handleCopyText = (text: string, isBlock = false, index: number | null = null) => {
    navigator.clipboard.writeText(text);
    if (isBlock && index !== null) {
      setCopiedCodeIndex(index);
      setTimeout(() => setCopiedCodeIndex(null), 2000);
    } else {
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2000);
    }
  };

  // Elegant text format helper for markdown-like text with syntax highlighted code blocks
  const renderFormattedText = (rawText: string) => {
    if (!rawText) return null;

    // Split text by code blocks ```...```
    const parts = rawText.split(/(```[a-z]*\n[\s\S]*?\n```)/g);

    return parts.map((part, index) => {
      if (part.startsWith('```')) {
        // Code Block
        const lines = part.split('\n');
        const language = lines[0].slice(3).trim() || 'code';
        const code = lines.slice(1, -1).join('\n');

        return (
          <div key={index} className="my-4 border border-slate-700/60 rounded-lg overflow-hidden bg-slate-950 font-mono text-sm shadow-inner">
            <div className="flex items-center justify-between px-4 py-1.5 bg-slate-900 border-b border-slate-800 text-xs text-slate-400">
              <span>{language}</span>
              <button
                onClick={() => handleCopyText(code, true, index)}
                className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
                title="Copy code"
              >
                {copiedCodeIndex === index ? (
                  <>
                    <Check size={13} className="text-emerald-500" />
                    <span className="text-emerald-500">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy size={13} />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 overflow-x-auto text-slate-300">
              <code>{code}</code>
            </pre>
          </div>
        );
      } else {
        // Plain text with support for bullet points, bold tags, and paragraphs
        const subLines = part.split('\n');
        return (
          <div key={index} className="space-y-2.5 text-slate-300 leading-relaxed">
            {subLines.map((line, sIndex) => {
              if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
                // Bullet points
                const content = line.trim().substring(2);
                return (
                  <ul key={sIndex} className="list-disc pl-5 text-slate-300 space-y-1 my-1">
                    <li>{parseInlineFormatting(content)}</li>
                  </ul>
                );
              } else if (line.trim().startsWith('#')) {
                // Headers
                const depth = (line.match(/^#+/) || [''])[0].length;
                const content = line.replace(/^#+\s*/, '');
                if (depth === 1) return <h1 key={sIndex} className="text-2xl font-bold text-white pt-4 pb-2 border-b border-slate-800/80">{parseInlineFormatting(content)}</h1>;
                if (depth === 2) return <h2 key={sIndex} className="text-xl font-semibold text-indigo-200 pt-3 pb-1">{parseInlineFormatting(content)}</h2>;
                return <h3 key={sIndex} className="text-lg font-medium text-indigo-300 pt-2">{parseInlineFormatting(content)}</h3>;
              } else if (line.trim() === '') {
                return <div key={sIndex} className="h-2" />;
              } else {
                return <p key={sIndex}>{parseInlineFormatting(line)}</p>;
              }
            })}
          </div>
        );
      }
    });
  };

  const parseInlineFormatting = (text: string) => {
    // Basic bold **text** and inline `code` parser
    const boldAndCodeRegex = /(\*\*.*?\*\*|`.*?`)/g;
    const parts = text.split(boldAndCodeRegex);

    return parts.map((part, index) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={index} className="font-semibold text-white">{part.slice(2, -2)}</strong>;
      } else if (part.startsWith('`') && part.endsWith('`')) {
        return <code key={index} className="bg-slate-900/80 text-indigo-300 px-1.5 py-0.5 rounded text-sm font-mono border border-slate-800">{part.slice(1, -1)}</code>;
      }
      return part;
    });
  };

  // Set generated image as input file to edit
  const useOutputAsInputImage = async () => {
    if (!imageOutput) return;
    try {
      setImagePreview(imageOutput);
      
      // Convert base64 dataurl back to a File object
      const res = await fetch(imageOutput);
      const blob = await res.blob();
      const file = new File([blob], 'edited-generation.png', { type: 'image/png' });
      setImageFile(file);
      
      // Focus the prompt text area
      setPrompt('');
    } catch (e) {
      console.error('Failed to set image output as input:', e);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200 antialiased">
      {/* Header Bar */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/10">
            <Sparkles className="text-white w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-slate-300">
              Gemini Studio
            </h1>
            <p className="text-[11px] text-slate-500 font-medium">Multi-Modal Creative Engine</p>
          </div>
        </div>

        {/* API Connection Indicator */}
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${status.connected ? 'bg-emerald-500 shadow-lg shadow-emerald-500/40 animate-ping' : 'bg-rose-500 shadow-lg shadow-rose-500/40'}`}></span>
          <span className="text-xs text-slate-400 font-medium">{status.message}</span>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Creator Workshop (Controls) */}
        <div className="lg:col-span-5 bg-slate-900/40 border border-slate-900 rounded-2xl p-5 flex flex-col gap-5 h-fit backdrop-blur-sm">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <h2 className="font-semibold text-white tracking-wide text-sm uppercase flex items-center gap-2">
              <Sliders size={15} className="text-indigo-400" />
              Creator Workshop
            </h2>
          </div>

          {/* Mode Selector */}
          <div className="grid grid-cols-3 bg-slate-950 p-1.5 rounded-xl border border-slate-900/80">
            <button
              onClick={() => setMode('text')}
              className={`py-2 px-3 rounded-lg text-xs font-semibold flex flex-col items-center gap-1.5 transition-all duration-200 cursor-pointer ${
                mode === 'text' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <MessageSquare size={16} />
              <span>Text Chat</span>
            </button>
            <button
              onClick={() => {
                setMode('speech');
                // Auto change default prompt to make it easier
                if (!prompt) setPrompt('Gemini is a powerful multi-modal intelligence developed by Google.');
              }}
              className={`py-2 px-3 rounded-lg text-xs font-semibold flex flex-col items-center gap-1.5 transition-all duration-200 cursor-pointer ${
                mode === 'speech' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <Volume2 size={16} />
              <span>Voice TTS</span>
            </button>
            <button
              onClick={() => setMode('image')}
              className={`py-2 px-3 rounded-lg text-xs font-semibold flex flex-col items-center gap-1.5 transition-all duration-200 cursor-pointer ${
                mode === 'image' 
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
              }`}
            >
              <ImageIcon size={16} />
              <span>Image Edit</span>
            </button>
          </div>

          {/* Dynamic Inputs based on selected mode */}
          <div className="flex flex-col gap-4">
            
            {/* 1. Prompt / Input Text */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-slate-300">
                {mode === 'text' && 'Describe your request or ask a question'}
                {mode === 'speech' && 'Type the text you want converted to speech'}
                {mode === 'image' && 'Describe the image you want to generate or modify'}
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={
                  mode === 'text' 
                    ? 'e.g., Explain quantum physics in simple terms...' 
                    : mode === 'speech' 
                    ? 'Enter text to synthesize (up to 500 characters)...' 
                    : 'e.g., A beautiful retro-cyberpunk landscape at sunset...'
                }
                className="w-full h-32 px-4 py-3 bg-slate-950 border border-slate-900 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 placeholder:text-slate-600 text-sm resize-none transition-all leading-relaxed"
              />
            </div>

            {/* 2. Advanced Multi-Modal Upload (for Text or Image modes) */}
            {mode !== 'speech' && (
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>{mode === 'text' ? 'Attach Image (Vision Input)' : 'Reference Image (Image Editing)'}</span>
                  {imagePreview && (
                    <button onClick={clearImage} className="text-[10px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer">
                      <Trash2 size={11} /> Clear
                    </button>
                  )}
                </label>

                {/* Drag & Drop Canvas */}
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border border-dashed rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-all ${
                    isDragOver 
                      ? 'border-indigo-500 bg-indigo-500/5' 
                      : imagePreview 
                      ? 'border-slate-800 bg-slate-950/20' 
                      : 'border-slate-800 hover:border-slate-700 hover:bg-slate-950/10'
                  }`}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept="image/*"
                    className="hidden"
                  />

                  {imagePreview ? (
                    <div className="flex items-center gap-3 w-full">
                      <img 
                        src={imagePreview} 
                        alt="Upload preview" 
                        className="w-16 h-16 object-cover rounded-lg border border-slate-800 shadow"
                      />
                      <div className="flex-1 text-left min-w-0">
                        <p className="text-xs font-semibold text-slate-300 truncate">{imageFile?.name || 'Input image'}</p>
                        <p className="text-[10px] text-slate-500">
                          {mode === 'text' ? 'Ready for multi-modal context' : 'Ready for instruction-based modification'}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2 text-center py-2">
                      <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-slate-400">
                        <Upload size={14} />
                      </div>
                      <p className="text-xs text-slate-400">
                        <span className="font-semibold text-indigo-400">Click to upload</span> or drag and drop image
                      </p>
                      <p className="text-[10px] text-slate-600">Supports PNG, JPG, WEBP</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 3. Parameters Drawer */}
            <div className="border border-slate-900 rounded-xl bg-slate-950/50 overflow-hidden">
              <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-900 flex items-center gap-2">
                <Sliders size={13} className="text-indigo-400" />
                <span className="text-xs font-bold text-slate-300">Model Parameters</span>
              </div>

              <div className="p-4 space-y-4">
                {/* Text Generation Parameters */}
                {mode === 'text' && (
                  <>
                    <div className="flex flex-col gap-1.5">
                      <div className="flex justify-between text-xs font-medium text-slate-400">
                        <span>Temperature</span>
                        <span className="text-indigo-400 font-semibold">{temperature}</span>
                      </div>
                      <input
                        type="range"
                        min="0.0"
                        max="2.0"
                        step="0.1"
                        value={temperature}
                        onChange={(e) => setTemperature(parseFloat(e.target.value))}
                        className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-medium text-slate-400">System Instruction</label>
                      <textarea
                        value={systemInstruction}
                        onChange={(e) => setSystemInstruction(e.target.value)}
                        className="w-full h-16 px-3 py-1.5 bg-slate-950 border border-slate-900 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 placeholder:text-slate-600 resize-none font-mono"
                      />
                    </div>
                  </>
                )}

                {/* Speech TTS Parameters */}
                {mode === 'speech' && (
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-slate-400">Select Voice</label>
                    <select
                      value={voiceName}
                      onChange={(e) => setVoiceName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-900 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 cursor-pointer"
                    >
                      <option value="Zephyr">Zephyr (Deep & Confident)</option>
                      <option value="Kore">Kore (Clear & Professional)</option>
                      <option value="Fenrir">Fenrir (Warm & Creative)</option>
                      <option value="Puck">Puck (Cheerful & Warm)</option>
                      <option value="Charon">Charon (Crisp & Direct)</option>
                    </select>
                  </div>
                )}

                {/* Image Parameters */}
                {mode === 'image' && (
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-slate-400">Aspect Ratio</label>
                    <div className="grid grid-cols-5 gap-1.5">
                      {['1:1', '3:4', '4:3', '9:16', '16:9'].map((ratio) => (
                        <button
                          key={ratio}
                          onClick={() => setAspectRatio(ratio)}
                          className={`py-1.5 rounded-lg text-[10px] font-bold border transition-all cursor-pointer ${
                            aspectRatio === ratio
                              ? 'border-indigo-500 bg-indigo-500/10 text-indigo-300'
                              : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          {ratio}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Generate Trigger Button */}
            <button
              onClick={handleGenerate}
              disabled={isPending || !status.connected}
              className={`w-full py-3 px-4 rounded-xl text-sm font-semibold tracking-wide text-white flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                isPending 
                  ? 'bg-slate-800 cursor-not-allowed shadow-inner' 
                  : !status.connected
                  ? 'bg-slate-900 text-slate-500 border border-slate-850 cursor-not-allowed'
                  : 'bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-500 hover:to-indigo-600 shadow-indigo-600/10 hover:shadow-indigo-600/20 active:scale-[0.98]'
              }`}
            >
              {isPending ? (
                <>
                  <RefreshCw size={15} className="animate-spin text-slate-400" />
                  <span>Synthesizing Canvas...</span>
                </>
              ) : (
                <>
                  <Sparkles size={15} />
                  <span>
                    {mode === 'text' && 'Generate Response'}
                    {mode === 'speech' && 'Synthesize Speech'}
                    {mode === 'image' && (imagePreview ? 'Edit with Instruction' : 'Create Image')}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Responsive Display Stage (Outputs) */}
        <div className={`lg:col-span-7 bg-slate-900/20 border border-slate-900 rounded-2xl flex flex-col overflow-hidden backdrop-blur-sm min-h-[500px] lg:min-h-0 ${expandedOutput ? 'fixed inset-4 z-[100] bg-slate-950/95 shadow-2xl' : ''}`}>
          
          {/* Output Header */}
          <div className="px-5 py-4 border-b border-slate-900 bg-slate-900/30 flex items-center justify-between">
            <h3 className="font-semibold text-white tracking-wide text-sm uppercase flex items-center gap-2">
              <Sparkles size={15} className="text-indigo-400" />
              Response Stage
            </h3>
            <div className="flex items-center gap-1.5">
              {/* Copy Full Output Button (Only if output exists) */}
              {mode === 'text' && textOutput && (
                <button
                  onClick={() => handleCopyText(textOutput)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60 transition-all cursor-pointer"
                  title="Copy full text response"
                >
                  {copiedText ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                </button>
              )}
              {/* Toggle Maximize output */}
              <button
                onClick={() => setExpandedOutput(!expandedOutput)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/60 transition-all cursor-pointer"
                title={expandedOutput ? 'Exit Full Screen' : 'View Full Screen'}
              >
                {expandedOutput ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
              </button>
            </div>
          </div>

          {/* Dynamic Content Container */}
          <div className="flex-1 p-5 overflow-y-auto max-h-[600px] lg:max-h-[650px] custom-scrollbar">
            <AnimatePresence mode="wait">
              {isPending ? (
                /* 1. Loading Pulse State */
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full flex flex-col items-center justify-center gap-4 py-20 text-center"
                >
                  <div className="relative">
                    <div className="w-16 h-16 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 flex items-center justify-center">
                      <Sparkles size={28} className="text-indigo-400 animate-pulse" />
                    </div>
                    <div className="absolute inset-0 rounded-2xl border-2 border-indigo-500 border-t-transparent animate-spin"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-200">Creative Synthesizer at Work</h4>
                    <p className="text-xs text-slate-500 mt-1 max-w-[280px]">
                      {mode === 'text' && 'Generating high-fidelity intelligence...'}
                      {mode === 'speech' && 'Synthesizing voice PCM data...'}
                      {mode === 'image' && 'Generating pixel-perfect visual matrix...'}
                    </p>
                  </div>
                </motion.div>
              ) : (
                /* Actual Content Display depending on state and selected mode */
                <div className="h-full">
                  {/* TEXT OUTPUT MODE */}
                  {mode === 'text' && (
                    textOutput ? (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-4"
                      >
                        {renderFormattedText(textOutput)}
                      </motion.div>
                    ) : (
                      <IdleState mode={mode} />
                    )
                  )}

                  {/* SPEECH OUTPUT MODE */}
                  {mode === 'speech' && (
                    audioBuffer ? (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex flex-col gap-6 py-4 max-w-lg mx-auto"
                      >
                        {/* Custom Audio Player Container */}
                        <div className="bg-slate-950 border border-slate-900 rounded-2xl p-6 shadow-xl flex flex-col gap-6">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-indigo-600/10 flex items-center justify-center text-indigo-400">
                              <Volume2 size={18} />
                            </div>
                            <div>
                              <h4 className="font-semibold text-slate-200 text-sm">Synthesized Audio Matrix</h4>
                              <p className="text-[11px] text-slate-500">Voice Profile: {voiceName}</p>
                            </div>
                          </div>

                          {/* Canvas Visualizer Waveform */}
                          <div className="relative bg-slate-900/30 rounded-xl overflow-hidden h-28 flex items-center justify-center border border-slate-900">
                            <canvas
                              ref={canvasRef}
                              width={400}
                              height={112}
                              className="w-full h-full"
                            />
                            {/* Floating duration tags */}
                            <div className="absolute bottom-2 left-3 text-[10px] font-mono text-slate-500">
                              {formatTime(audioProgress)}
                            </div>
                            <div className="absolute bottom-2 right-3 text-[10px] font-mono text-slate-500">
                              {formatTime(audioDuration)}
                            </div>
                          </div>

                          {/* Media Playback Controls */}
                          <div className="flex items-center justify-between gap-4">
                            {/* Play/Pause Button */}
                            <button
                              onClick={toggleAudioPlayback}
                              className="w-12 h-12 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center shadow-lg shadow-indigo-600/20 active:scale-95 transition-all cursor-pointer"
                            >
                              {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-1" />}
                            </button>

                            {/* Vol and Speed controllers */}
                            <div className="flex-1 flex flex-col gap-2.5 px-2">
                              {/* Volume control */}
                              <div className="flex items-center gap-3">
                                <span className="text-[10px] font-bold text-slate-500 tracking-wide uppercase w-10 text-left">Volume</span>
                                <input
                                  type="range"
                                  min="0"
                                  max="1"
                                  step="0.05"
                                  value={volume}
                                  onChange={(e) => {
                                    setVolume(parseFloat(e.target.value));
                                    if (audioSource && audioContext) {
                                      // Dynamically adjust gain if already playing if possible
                                    }
                                  }}
                                  className="flex-1 h-1 bg-slate-800 accent-indigo-500 rounded-lg cursor-pointer"
                                />
                              </div>

                              {/* Playback speed */}
                              <div className="flex items-center gap-3">
                                <span className="text-[10px] font-bold text-slate-500 tracking-wide uppercase w-10 text-left">Speed</span>
                                <div className="flex-1 flex gap-1">
                                  {[0.8, 1.0, 1.25, 1.5].map((speed) => (
                                    <button
                                      key={speed}
                                      onClick={() => {
                                        setPlaybackSpeed(speed);
                                        if (isPlaying) {
                                          // Restart playing at new speed
                                          pauseAudioPlayback();
                                          setTimeout(playAudioPlayback, 50);
                                        }
                                      }}
                                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold border transition-all cursor-pointer ${
                                        playbackSpeed === speed
                                          ? 'border-indigo-500 bg-indigo-500/15 text-indigo-400'
                                          : 'border-slate-850 bg-slate-900/60 text-slate-500 hover:border-slate-700'
                                      }`}
                                    >
                                      {speed}x
                                    </button>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Download Button */}
                            <button
                              onClick={downloadAudioWav}
                              className="w-10 h-10 rounded-xl border border-slate-800 bg-slate-950 hover:bg-slate-900 hover:border-slate-700 text-slate-300 flex items-center justify-center transition-all cursor-pointer"
                              title="Download WAV"
                            >
                              <Download size={14} />
                            </button>
                          </div>
                        </div>

                        {/* Text reference of the speech */}
                        <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4">
                          <span className="text-[9px] uppercase tracking-wider font-bold text-slate-600 block mb-1.5">Original Transcript</span>
                          <p className="text-xs text-slate-400 italic leading-relaxed">"{prompt}"</p>
                        </div>
                      </motion.div>
                    ) : (
                      <IdleState mode={mode} />
                    )
                  )}

                  {/* IMAGE OUTPUT MODE */}
                  {mode === 'image' && (
                    imageOutput ? (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="flex flex-col gap-4 py-2 max-w-lg mx-auto"
                      >
                        {/* Image Output Card */}
                        <div className="bg-slate-950 border border-slate-900 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
                          <div className="p-4 bg-slate-900/20 border-b border-slate-900 flex items-center justify-between">
                            <span className="text-xs font-semibold text-indigo-300 flex items-center gap-1">
                              <Sparkles size={12} /> Image Generation Complete
                            </span>
                            <div className="flex gap-1">
                              {/* Re-inject to Edit button */}
                              <button
                                onClick={useOutputAsInputImage}
                                className="px-2.5 py-1 text-[10px] font-bold rounded bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1 cursor-pointer"
                                title="Load this image back as a Vision input for modifications"
                              >
                                <Upload size={10} />
                                <span>Modify This Image</span>
                              </button>
                              
                              {/* Download button */}
                              <a
                                href={imageOutput}
                                download={`gemini-image-${Date.now()}.png`}
                                className="p-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 cursor-pointer"
                                title="Download image"
                              >
                                <Download size={12} />
                              </a>
                            </div>
                          </div>

                          {/* Image rendering area */}
                          <div className="bg-slate-950 flex items-center justify-center p-2 relative group max-h-[450px] overflow-hidden">
                            <img
                              src={imageOutput}
                              alt="Gemini generated art"
                              className="w-full h-auto object-contain rounded-lg max-h-[430px]"
                            />
                          </div>
                        </div>

                        {/* Meta summary */}
                        <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-3 text-xs flex justify-between text-slate-500">
                          <span>Prompt: <span className="text-slate-300">"{prompt || 'Default high-detail'}"</span></span>
                          <span className="shrink-0 ml-4 font-semibold text-slate-400">Ratio {aspectRatio}</span>
                        </div>
                      </motion.div>
                    ) : (
                      <IdleState mode={mode} />
                    )
                  )}
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>

      {/* Footer Branding */}
      <footer className="border-t border-slate-950 bg-slate-950 py-4 text-center">
        <p className="text-[10px] text-slate-600 tracking-wide">
          Crafted with professional composition using Google Gemini 3.5 & 3.1 TTS Engines.
        </p>
      </footer>
    </div>
  );
}

// Minimal placeholder subcomponent for empty state
function IdleState({ mode }: { mode: AppMode }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center py-24 px-6 gap-5">
      <div className="w-14 h-14 rounded-full bg-slate-900/60 flex items-center justify-center border border-slate-800/80">
        {mode === 'text' && <MessageSquare className="text-slate-500" size={22} />}
        {mode === 'speech' && <Volume2 className="text-slate-500" size={22} />}
        {mode === 'image' && <ImageIcon className="text-slate-500" size={22} />}
      </div>
      <div className="max-w-md space-y-2">
        <h4 className="font-semibold text-slate-300">
          {mode === 'text' && 'Intellect Canvas is Idle'}
          {mode === 'speech' && 'Acoustic Synthesizer is Idle'}
          {mode === 'image' && 'Visual Composition Canvas is Idle'}
        </h4>
        <p className="text-xs text-slate-500 leading-relaxed">
          {mode === 'text' && 'Configure your instruction, enter a descriptive text prompt, and optionally attach an image file. Click Generate to stream intelligence.'}
          {mode === 'speech' && 'Provide any article, transcript, or single sentence text. Select a curated premium vocal model, then synthesize to hear high-fidelity speech.'}
          {mode === 'image' && 'Describe a visual scene. You can optionally upload a reference image, and direct the model to add elements or make targeted adjustments.'}
        </p>
      </div>
    </div>
  );
}

// Standard time formatter
function formatTime(secs: number): string {
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

